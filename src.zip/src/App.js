// import logo from './logo.svg';
//import './App.css';

import PowerWheel from './PowerWheel';
function App() {
  return (
    <div className="App">
      
     <h1>Power Wheel (Demo)</h1>
     <PowerWheel />
    </div>
  );
}

export default App;
